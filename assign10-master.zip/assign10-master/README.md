# assign10

If you get an error upon running the app that says "'IrisSpecies' not found," run the 'model.R' file contents in the 'inst' folder, then re-run the app. The app should run then.
